class CustomToast{
      toastBox;
      duration;
      toastIcon = {
        success: `<span class="material-symbols-outlined">task_alt</span>`,
        danger: `<span class="material-symbols-outlined">error</span>`,
        warning: `<span class="material-symbols-outlined">warning</span>`,
        info: `<span class="material-symbols-outlined">info</span>`
    };
    show(message="Sample Message", toastType="info", duration = 5000){
        if(!Object.keys(this.toastIcon).includes(toastType))
            toastType = `info`;
            this.toastBox = document.createElement('div')
            this.toastBox.classList.add('toast', `toast-${toastType}`)
            this.toastBox.innerHTML = `<button class="toast-close-btn"><span class="material-symbols-outlined">close</span></button>
            <div class="toast-content-wrapper">
                <div class="toast-icon">
                    ${this.toastIcon[toastType]}
                </div>
                <div class="toast-message">${message}</div>
                <div class="toast-progress"></div>
            </div>`;
             this.duration = duration
             this.toastBox.querySelector('.toast-progress').style.animationDuration = `${this.duration / 1000}s`
        if(document.body.querySelector('.toast') != null)
            document.body.querySelector('.toast').remove();
        document.body.appendChild(this.toastBox)
        this.triggerClose()
        this.toastBox.querySelector('.toast-close-btn').addEventListener('click', e=>{
            e.preventDefault()
            this.triggerClose(0)
        })
    }
    triggerClose(closeDuration = null){
            if(closeDuration == null){
            closeDuration=this.duration
        }
        setTimeout(()=>{
            this.toastBox.classList.add('closing')
            this.closeToast()
        },closeDuration)
    }
    closeToast(){
            setTimeout(()=>{
            this.toastBox.remove();
        }, 500)
    }
}