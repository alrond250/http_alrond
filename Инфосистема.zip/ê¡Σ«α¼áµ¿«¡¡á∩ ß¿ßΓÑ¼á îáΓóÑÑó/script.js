const successToast = document.querySelector('.btn-toast.btn-success-toast')
const infoToast = document.querySelector('.btn-toast.btn-info-toast')
const dangerToast = document.querySelector('.btn-toast.btn-danger-toast')
const warningToast = document.querySelector('.btn-toast.btn-warning-toast')

successToast.addEventListener('click', e=>{
    e.preventDefault()
    new CustomToast().show(`<a style="" href="page1.html">15 мая 2023 года состоится "Олимпиада "Алгоритмика"</a>`, 'success', 10000)
})

infoToast.addEventListener('click', e=>{
    e.preventDefault()
    new CustomToast().show(`14 апреля прошли соревнования "Знаток ПТЭ"`, 'info', 10000)
})

